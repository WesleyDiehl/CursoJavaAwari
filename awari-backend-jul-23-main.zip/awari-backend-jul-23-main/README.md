# Exercícios do curso da Awari de Backend

## Testando exemplos
