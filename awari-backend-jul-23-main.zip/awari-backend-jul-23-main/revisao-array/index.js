const nomes = ['Daniel', 'Diehl', 'Bruno']
const cursos = ['JS', 'Backend', 'React']
const hobbies = ['Ler livros', 'Caminhar', 'Praticar esporte']

const array = [];
const usuarios = [{
    nome: 'Bruno',
    curso: 'Backend',
    hobby: 'Ler livros'
},{
    nome: 'Diehl',
    curso: 'JS',
    hobby: 'Caminhar'
},{
    nome: 'Daniel',
    curso: 'React',
    hobby: 'Praticar esporte'
}]